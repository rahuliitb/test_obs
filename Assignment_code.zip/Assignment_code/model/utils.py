import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt


def plot_confusion_matrix_with_labels(y_true, y_pred, title="Confusion Matrix"):
    """
    Plots a confusion matrix with TP, FP, FN, TN labels using seaborn heatmap.

    Parameters:
    - y_true: array-like of shape (n_samples,) - True labels.
    - y_pred: array-like of shape (n_samples,) - Predicted labels.
    - title: str, optional - Title for the plot.
    """
    cm = confusion_matrix(y_true, y_pred)
    labels = [["TN", "FP"],
              ["FN", "TP"]]
    annot = [[f"{labels[i][j]}\n{cm[i, j]}" for j in range(2)] for i in range(2)]

    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=annot, fmt="", cmap="Blues", cbar=False,
                xticklabels=["Not Churn", "Churn"],
                yticklabels=["Not Churn", "Churn"])
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title(title)
    plt.show()



def cramers_v(x, y):
    confusion_matrix = pd.crosstab(x, y)
    chi2 = chi2_contingency(confusion_matrix)[0]
    n = confusion_matrix.sum().sum()
    phi2 = chi2 / n
    r, k = confusion_matrix.shape
    return np.sqrt(phi2 / min(k - 1, r - 1))


class CramersVSelector(BaseEstimator, TransformerMixin):
    def __init__(self, variables=None, threshold=0.7):
        """
        Drop categorical variables that are highly correlated using Cramér's V.
        
        Parameters
        ----------
        variables : list of str
            Categorical variable names.
        threshold : float
            Maximum allowed Cramér's V correlation.
        """
        self.variables = variables
        self.threshold = threshold

    def fit(self, X, y=None):
        X = pd.DataFrame(X).copy()
        self.input_features_ = X.select_dtypes(include=['object','category']).columns

        cat_vars = self.variables if self.variables is not None else self.input_features_

        drop = set()
        if  len(cat_vars) > 0:
            for i, f1 in enumerate(cat_vars):
                if f1 in drop:
                    continue
                for j, f2 in enumerate(cat_vars):
                    if i < j and f2 not in drop:
                        cv = cramers_v(X[f1], X[f2])
                        if cv > self.threshold:
                            drop.add(f2)

        self.features_to_drop_ = list(drop)
        self.features_to_keep_ = [f for f in cat_vars if f not in drop]
        return self

    def transform(self, X):
        X = pd.DataFrame(X).copy()
        return X[self.features_to_keep_]

  
    def set_output(self, *, transform=None):
        """Sklearn compatibility: allow set_output(transform="pandas")."""
        self._transform_output = transform
        return self

    def get_feature_names_out(self, input_features=None):
        """Return the names of the kept features."""
        if input_features is None:
            input_features = self.input_features_
        return np.array([f for f in input_features if f in self.features_to_keep_])




class ToCategorical(BaseEstimator, TransformerMixin):
    def __init__(self, variables=None):
        self.variables = variables

    def fit(self, X, y=None):
        # mark as fitted following sklearn convention
        self.is_fitted_ = True
        return self

    def transform(self, X):
        # check fitted status
        check_is_fitted(self, "is_fitted_")

        X = X.copy()
        cols = self.variables if self.variables is not None else X.select_dtypes(include=['object','category']).columns
        if cols is not None:
            for col in cols:
                if col in X.columns:
                    X[col] = X[col].astype("category")
        return X

    def get_feature_names_out(self, input_features=None):
        return self.feature_names_in_