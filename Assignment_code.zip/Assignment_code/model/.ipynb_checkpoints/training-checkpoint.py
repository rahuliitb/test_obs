import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import lightgbm as lgb
from lightgbm import early_stopping
from loguru import logger
from datetime import datetime

from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, RandomizedSearchCV, ParameterSampler
from sklearn.feature_selection import RFECV


class LightGBM(BaseEstimator , ClassifierMixin):
    def __init__(self, param_dist: dict, n_iter: int =100, cv_splits: int =5, random_state: int =42, 
                stopping_rounds: int =20, scoring: str ="roc_auc",
                tol: float =0.01
                ):
        self.param_dist = param_dist
        self.n_iter = n_iter
        self.cv_splits = cv_splits
        self.random_state = random_state
        self.stopping_rounds = stopping_rounds
        self.scoring = scoring
        self.tol = tol
        
        # Tracking variables
        self.hyperparameter_search_results = []
        self.cv_fold_results = []
       
        
    def fit(self, X, y):

        # Step 1: Get the best hyperparameters
        logger.info("Getting the best hyperparameters")
        # Initialize best scores and parameters
        best_score_train = -np.inf
        best_score_val = -np.inf
        best_params = None
        best_iterations = None

        # Initialize cross-validation
        cv = StratifiedKFold(n_splits=self.cv_splits, shuffle=True, random_state=self.random_state)

        iteration_count = 0
        for params in ParameterSampler(self.param_dist, n_iter=self.n_iter, random_state=self.random_state):
            iteration_count += 1
            fold_scores_train = []
            fold_scores_val = []
            fold_iterations = []
            fold_details = []

            for fold_idx, (train_idx, val_idx) in enumerate(cv.split(X, y)):
                X_tr, X_val = X.iloc[train_idx], X.iloc[val_idx]
                y_tr, y_val = y.iloc[train_idx], y.iloc[val_idx]

                model = lgb.LGBMClassifier(**params, random_state=self.random_state, verbosity=-1)
                model.fit(
                    X_tr, y_tr,
                    eval_set=[(X_val, y_val)],
                    eval_metric="auc",
                    callbacks=[lgb.early_stopping(self.stopping_rounds, verbose=False)]
                     
                    
                )

                y_pred_train = model.predict_proba(X_tr)[:, 1]  
                y_pred_val = model.predict_proba(X_val)[:, 1]
                fold_train_score = roc_auc_score(y_tr, y_pred_train)
                fold_val_score = roc_auc_score(y_val, y_pred_val)
                
                fold_scores_train.append(fold_train_score)
                fold_scores_val.append(fold_val_score)
                fold_iterations.append(model.best_iteration_)
                
                # Store fold details for MLflow logging
                fold_details.append({
                    'fold': fold_idx,
                    'train_score': fold_train_score,
                    'val_score': fold_val_score,
                    'iterations': model.best_iteration_
                })

            mean_score_train = np.mean(fold_scores_train)
            mean_score_val = np.mean(fold_scores_val)
            std_score_train = np.std(fold_scores_train)
            std_score_val = np.std(fold_scores_val)
            mean_iter = int(np.mean(fold_iterations))

            # Store hyperparameter search results
            search_result = {
                'iteration': iteration_count,
                'params': params.copy(),
                'mean_train_score': mean_score_train,
                'mean_val_score': mean_score_val,
                'std_train_score': std_score_train,
                'std_val_score': std_score_val,
                'mean_iterations': mean_iter,
                'fold_details': fold_details
            }
            self.hyperparameter_search_results.append(search_result)

            if mean_score_val> best_score_val:
                best_score_val = mean_score_val
                best_score_train = mean_score_train
                best_params = params
                best_iterations = mean_iter
                
                # Track best score update
                
                
        best_params.update({'n_estimators': best_iterations})
        
        # Save results
        self.best_params_ = best_params
        self.best_score_val = best_score_val
        self.best_score_train = best_score_train
        self.best_iteration_ = best_iterations
        logger.info(f"Best parameters: {self.best_params_}")
        logger.info(f"Best validation score: {self.best_score_val} and train score: {self.best_score_train}")
        logger.info(f"Best iteration: {self.best_iteration_}")

      

        # Step 2: Feature selection with elbow method(RFECV)
        logger.info("Feature selection with elbow method(RFECV) started")
        
        
        # Feature selection
        rfecv = RFECV(
            estimator=lgb.LGBMClassifier(**self.best_params_, random_state=self.random_state, verbosity=-1),
            step=1,
            cv=cv,
            scoring= self.scoring,
            n_jobs=-1,
            min_features_to_select=1,
            verbose=0
        )
        rfecv.fit(X, y)
        logger.info("Feature selection with elbow method(RFECV) completed")
        
        # Extract CV scores
        self.scores = rfecv.cv_results_["mean_test_score"]
        self.n_features = rfecv.cv_results_["n_features"]

        # Absolute best
        best_idx = np.argmax(self.scores)
        self.best_n = self.n_features[best_idx]
        self.best_auc = self.scores[best_idx]

        # Tolerance-based elbow
        max_auc = np.max(self.scores)
        self.tolerance = self.tol
        tol_idx = np.where(self.scores >= max_auc - self.tolerance)[0][0]
        self.n_tolerant = self.n_features[tol_idx]
        self.tolerant_auc = self.scores[tol_idx]

        # Feature names
        feature_names = np.array(rfecv.feature_names_in_)

        # Best set (RFECV's selection)
        best_features = feature_names[rfecv.support_]

        # Elbow set
        ranking = rfecv.ranking_
        if np.all(ranking == 1):
            
            importances = rfecv.estimator_.feature_importances_
            sorted_idx = np.argsort(importances)[::-1]
            elbow_features = feature_names[sorted_idx[:self.n_tolerant]]
        else:
            sorted_idx = np.argsort(ranking)[:self.n_tolerant]
            elbow_features = feature_names[sorted_idx]

        self.best_features_ = best_features
        self.selected_features_ = elbow_features
        logger.info( f"Best features: {self.best_features_} and selected features: {self.selected_features_}")
        
        
        
        # Step 3: Retrain final model on elbow features
        logger.info("Retraining final model on selected features started")
        
        # Final model training
        final_model = lgb.LGBMClassifier(
            **self.best_params_,
            
            random_state=self.random_state,
            verbose=-1
        )

        final_model.fit(
           X[self.selected_features_], y
        )

        self.final_model_ = final_model
        logger.info("Retraining final model on selected features completed ")
        
        # Training complete
        logger.info(f"Hyperparameter search: {len(self.hyperparameter_search_results)} iterations completed")
        logger.info(f"Best validation AUC: {self.best_score_val:.4f}")
        logger.info(f"Selected features: {len(self.selected_features_)}")
        logger.info("Model training completed successfully!")
        
        return self
        
    def plot_RFECV_elbow_curve(self):
        
        if self.scores is None:
            raise ValueError("Please fit the model first.")

        plt.figure(figsize=(9,6))
        plt.plot(self.n_features, self.scores, marker="o", label="CV ROC-AUC")
        plt.xlabel("Number of features selected")
        plt.ylabel("Cross-validated ROC-AUC")
        plt.title("RFECV - AUC vs Number of Features")
        plt.grid(True)

        plt.axvline(self.best_n, color="red", linestyle="--", alpha=0.7)
        plt.scatter([self.best_n], [self.best_auc], color="red", s=120, 
                    label=f"Best = {self.best_n} features (AUC={self.best_auc:.4f})")

        plt.axvline(self.n_tolerant, color="green", linestyle="--", alpha=0.7)
        plt.scatter([self.n_tolerant], [self.tolerant_auc], color="green", s=120, 
                    label=f"Elbow = {self.n_tolerant} features (AUC={self.tolerant_auc:.4f})")

        plt.legend()
        plt.show()
    
    def predict_proba(self, X):
        if self.final_model_ is None:
            raise ValueError("Please fit the model first.")
        return self.final_model_.predict_proba(X[self.selected_features_])[:, 1]
    
    def get_hyperparameter_search_results(self):
        """Return detailed hyperparameter search results for analysis"""
        return self.hyperparameter_search_results
    
    def get_best_hyperparameters(self):
        """Return the best hyperparameters found during search"""
        return {
            'best_params': self.best_params_,
            'best_val_score': self.best_score_val,
            'best_train_score': self.best_score_train,
            'best_iteration': self.best_iteration_,
            'selected_features': self.selected_features_,
            'search_iterations': len(self.hyperparameter_search_results)
        }
    
   
    